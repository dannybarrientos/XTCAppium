package global;

/**
 * Created by matisseh on 2/7/17.
 */
public enum Platform {
    ANDROID,
    IOS
}
